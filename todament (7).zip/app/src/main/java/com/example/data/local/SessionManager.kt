package com.example.data.local

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {
  private val prefs: SharedPreferences = context.applicationContext.getSharedPreferences(
    PREFS_NAME,
    Context.MODE_PRIVATE
  )

  companion object {
    private const val PREFS_NAME = "todament_user_session"
    private const val KEY_USER_EMAIL = "logged_in_user_email"
    private const val KEY_USER_TOKEN = "logged_in_user_token"

    @Volatile
    private var instance: SessionManager? = null

    fun getInstance(context: Context): SessionManager {
      return instance ?: synchronized(this) {
        instance ?: SessionManager(context).also { instance = it }
      }
    }
  }

  fun saveSession(email: String, token: String? = null) {
    prefs.edit()
      .putString(KEY_USER_EMAIL, email)
      .putString(KEY_USER_TOKEN, token ?: email)
      .apply()
  }

  fun getLoggedInUserEmail(): String? {
    return prefs.getString(KEY_USER_EMAIL, null)
  }

  fun clearSession() {
    prefs.edit()
      .remove(KEY_USER_EMAIL)
      .remove(KEY_USER_TOKEN)
      .apply()
  }

  fun isLoggedIn(): Boolean {
    return !getLoggedInUserEmail().isNullOrBlank()
  }
}
