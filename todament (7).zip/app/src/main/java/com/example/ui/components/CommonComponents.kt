package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.model.MatchFormat
import com.example.data.model.MatchStatus
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun FormatBadge(format: MatchFormat, modifier: Modifier = Modifier) {
  val (bgColor, textColor) = when (format) {
    MatchFormat.SOLO -> Color(0xFF1E293B) to Color(0xFF94A3B8)
    MatchFormat.DUO -> Color(0xFF0F3B3F) to NeonCyan
    MatchFormat.SQUAD -> Color(0xFF0D3B23) to EmeraldNeon
    MatchFormat.CLASH_SQUAD -> Color(0xFF3F2B0F) to AmberGold
  }
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(6.dp))
      .background(bgColor)
      .border(1.dp, textColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
      .padding(horizontal = 8.dp, vertical = 3.dp)
  ) {
    Text(
      text = format.displayName.uppercase(),
      style = MaterialTheme.typography.labelSmall,
      color = textColor,
      fontWeight = FontWeight.Bold,
      fontSize = 10.sp
    )
  }
}

@Composable
fun MapBadge(mapName: String, modifier: Modifier = Modifier) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(6.dp))
      .background(CarbonCardElevated)
      .border(1.dp, CarbonBorder, RoundedCornerShape(6.dp))
      .padding(horizontal = 8.dp, vertical = 3.dp)
  ) {
    Text(
      text = mapName.uppercase(),
      style = MaterialTheme.typography.labelSmall,
      color = TextSecondary,
      fontWeight = FontWeight.Medium,
      fontSize = 10.sp
    )
  }
}

@Composable
fun StatusBadge(status: MatchStatus, modifier: Modifier = Modifier) {
  val (color, label) = when (status) {
    MatchStatus.OPEN -> EmeraldNeon to "REGISTRATION OPEN"
    MatchStatus.FULL -> AmberGold to "SLOTS FULL"
    MatchStatus.LIVE -> CrimsonAlert to "LIVE SCRIM"
    MatchStatus.COMPLETED -> Color(0xFF94A3B8) to "COMPLETED"
    MatchStatus.CANCELLED -> CrimsonAlert to "CANCELLED"
  }
  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = modifier
      .clip(RoundedCornerShape(6.dp))
      .background(color.copy(alpha = 0.12f))
      .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
      .padding(horizontal = 8.dp, vertical = 3.dp)
  ) {
    Box(
      modifier = Modifier
        .size(6.dp)
        .clip(CircleShape)
        .background(color)
    )
    Spacer(modifier = Modifier.width(5.dp))
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = color,
      fontWeight = FontWeight.Bold,
      fontSize = 10.sp
    )
  }
}

@Composable
fun CopyableCodeBox(
  label: String,
  value: String,
  modifier: Modifier = Modifier,
  testTag: String = "copy_code_box"
) {
  val context = LocalContext.current
  Card(
    colors = CardDefaults.cardColors(containerColor = CarbonCard),
    shape = RoundedCornerShape(10.dp),
    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
    modifier = modifier
      .fillMaxWidth()
      .testTag(testTag)
  ) {
    Row(
      modifier = Modifier
        .padding(horizontal = 12.dp, vertical = 8.dp)
        .fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Text(
          text = value,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
          color = EmeraldNeon
        )
      }
      IconButton(
        onClick = {
          val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
          val clip = ClipData.newPlainText(label, value)
          clipboard.setPrimaryClip(clip)
          Toast.makeText(context, "$label copied!", Toast.LENGTH_SHORT).show()
        },
        modifier = Modifier.size(36.dp)
      ) {
        Icon(
          imageVector = Icons.Default.ContentCopy,
          contentDescription = "Copy $label",
          tint = NeonCyan,
          modifier = Modifier.size(18.dp)
        )
      }
    }
  }
}

@Composable
fun ZoomableImageDialog(
  imageUrl: String,
  title: String = "Payment Proof",
  onDismiss: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = CarbonCardElevated,
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark))),
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(text = title, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
          }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(350.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(CarbonBackground),
          contentAlignment = Alignment.Center
        ) {
          AsyncImage(
            model = imageUrl,
            contentDescription = title,
            modifier = Modifier.fillMaxSize()
          )
        }
      }
    }
  }
}

@Composable
fun TodamentHeader(
  userName: String?,
  userIgn: String?,
  balance: Double,
  isAdmin: Boolean,
  onWalletClick: () -> Unit,
  onAdminClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .background(CarbonBackground)
      .padding(horizontal = 16.dp, vertical = 12.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .clip(RoundedCornerShape(10.dp))
          .background(Brush.linearGradient(listOf(EmeraldNeon, NeonCyan)))
          .padding(2.dp),
        contentAlignment = Alignment.Center
      ) {
        Image(
          painter = painterResource(id = R.drawable.app_logo),
          contentDescription = "Todament Esports Logo",
          modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(8.dp))
        )
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = userIgn ?: "Gamer",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          if (isAdmin) {
            Spacer(modifier = Modifier.width(6.dp))
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(CrimsonAlert)
                .clickable { onAdminClick() }
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(
                text = "ADMIN",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 9.sp
              )
            }
          }
        }
        Text(
          text = if (isAdmin) "Super Admin Suite" else "Free Fire Player",
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary,
          fontSize = 11.sp
        )
      }
    }

    // Wallet Balance Chip
    Surface(
      onClick = onWalletClick,
      shape = RoundedCornerShape(20.dp),
      color = CarbonCardElevated,
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(EmeraldDark, EmeraldNeon.copy(alpha = 0.5f)))),
      modifier = Modifier.testTag("wallet_balance_header_chip")
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = Icons.Default.AccountBalanceWallet,
          contentDescription = "Wallet Balance",
          tint = EmeraldNeon,
          modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "₹${"%.0f".format(balance)}",
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp,
          color = TextPrimary
        )
      }
    }
  }
}
