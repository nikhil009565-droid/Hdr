package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AppSettings
import com.example.data.model.PromotionalBanner
import kotlinx.coroutines.flow.Flow

@Dao
interface AppConfigDao {
  // Banners
  @Query("SELECT * FROM promotional_banners WHERE isActive = 1 ORDER BY orderIndex ASC")
  fun getActiveBanners(): Flow<List<PromotionalBanner>>

  @Query("SELECT * FROM promotional_banners ORDER BY orderIndex ASC")
  fun getAllBanners(): Flow<List<PromotionalBanner>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBanner(banner: PromotionalBanner)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBanners(banners: List<PromotionalBanner>)

  @Update
  suspend fun updateBanner(banner: PromotionalBanner)

  @Delete
  suspend fun deleteBanner(banner: PromotionalBanner)

  // App Settings
  @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
  fun getSettings(): Flow<AppSettings?>

  @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
  suspend fun getSettingsSync(): AppSettings?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun saveSettings(settings: AppSettings)
}
