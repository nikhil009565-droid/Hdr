package com.example.ui.screens.admin

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import coil.compose.AsyncImage
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppSettings
import com.example.data.model.PromotionalBanner
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TodamentViewModel
import java.util.UUID

@Composable
fun AdminSettingsBackupTab(viewModel: TodamentViewModel) {
  val context = LocalContext.current
  val currentSettings by viewModel.appSettings.collectAsState()
  val allBanners by viewModel.allBanners.collectAsState()

  // Settings local state
  var adminUpiId by remember(currentSettings) { mutableStateOf(currentSettings.adminUpiId) }
  var adminPayeeName by remember(currentSettings) { mutableStateOf(currentSettings.adminPayeeName) }
  var minDepositStr by remember(currentSettings) { mutableStateOf(currentSettings.minDepositAmount.toInt().toString()) }
  var minWithdrawalStr by remember(currentSettings) { mutableStateOf(currentSettings.minWithdrawalAmount.toInt().toString()) }
  var refTier1Str by remember(currentSettings) { mutableStateOf(currentSettings.referralFirstWinPercent.toInt().toString()) }
  var refTier2Str by remember(currentSettings) { mutableStateOf(currentSettings.referralSubsequentWinPercent.toInt().toString()) }
  var announcement by remember(currentSettings) { mutableStateOf(currentSettings.announcementNotice) }
  var telegramHelpUrl by remember(currentSettings) { mutableStateOf(currentSettings.telegramHelpUrl) }
  var qrCodeImageUri by remember(currentSettings) { mutableStateOf(currentSettings.qrCodeImageUri) }

  val qrCodePickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia(),
    onResult = { uri ->
      if (uri != null) {
        qrCodeImageUri = uri.toString()
        Toast.makeText(context, "QR code image selected from gallery!", Toast.LENGTH_SHORT).show()
      }
    }
  )

  // Banner Add Dialog
  var showAddBannerDialog by remember { mutableStateOf(false) }

  // Restore Dialog
  var showRestoreDialog by remember { mutableStateOf(false) }
  var jsonRestoreInput by remember { mutableStateOf("") }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground),
    contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 90.dp)
  ) {
    // 1. DATA PROTECTION & 1-CLICK BACKUP / RESTORE
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(EmeraldDark, EmeraldNeon))),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Security, contentDescription = null, tint = EmeraldNeon, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "DATA PROTECTION & BACKUP SUITE",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Black,
              color = EmeraldNeon,
              letterSpacing = 0.5.sp
            )
          }

          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Permanent SQLite database protects records across reboots and app updates. Export JSON backup for absolute peace of mind.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            fontSize = 11.sp
          )

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = {
                viewModel.exportBackup { jsonContent ->
                  // Share as file / text
                  val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/json"
                    putExtra(Intent.EXTRA_SUBJECT, "TODAMENT_Backup_${System.currentTimeMillis()}.json")
                    putExtra(Intent.EXTRA_TEXT, jsonContent)
                  }
                  context.startActivity(Intent.createChooser(shareIntent, "Save or Share Backup (.json)"))
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier
                .weight(1f)
                .testTag("btn_download_backup")
            ) {
              Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Download Backup (.json)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
              onClick = { showRestoreDialog = true },
              colors = ButtonDefaults.buttonColors(containerColor = CarbonCardElevated, contentColor = NeonCyan),
              border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier
                .weight(1f)
                .testTag("btn_restore_backup")
            ) {
              Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Restore Backup File", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    // 2. PAYMENT & APP SETTINGS FORM
    item {
      Spacer(modifier = Modifier.height(20.dp))
      Text(
        text = "PAYMENT & REWARD CONFIGURATION",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )
      Spacer(modifier = Modifier.height(8.dp))

      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonCard),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          OutlinedTextField(
            value = adminUpiId,
            onValueChange = { adminUpiId = it },
            label = { Text("Admin Official UPI ID") },
            placeholder = { Text("e.g. todament@upi") },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = adminPayeeName,
            onValueChange = { adminPayeeName = it },
            label = { Text("Admin Payee Full Business Name") },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(14.dp))

          // --- ADMIN UPI QR CODE SETUP ---
          Text(
            text = "ADMIN UPI QR CODE CONFIGURATION",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Black,
            color = EmeraldNeon,
            letterSpacing = 0.5.sp
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Players will scan this QR Code in the Add Money/Deposit dialog. Upload your official PhonePe, GPay, or Paytm QR image, paste a direct URL, or leave blank to auto-generate from your UPI ID.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            fontSize = 11.sp
          )
          Spacer(modifier = Modifier.height(8.dp))

          OutlinedTextField(
            value = qrCodeImageUri,
            onValueChange = { qrCodeImageUri = it },
            label = { Text("Custom QR Image URL / Picked URI") },
            placeholder = { Text("https://example.com/qr.png or select from gallery") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldNeon,
              unfocusedBorderColor = CarbonBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_admin_qr_url")
          )

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Button(
              onClick = {
                qrCodePickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
              },
              colors = ButtonDefaults.buttonColors(containerColor = CarbonCardElevated, contentColor = NeonCyan),
              border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.weight(1f).testTag("btn_pick_qr_from_gallery")
            ) {
              Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Upload QR from Gallery", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            if (qrCodeImageUri.isNotBlank()) {
              OutlinedButton(
                onClick = { qrCodeImageUri = "" },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(0.8f).testTag("btn_clear_custom_qr")
              ) {
                Text("Reset to Auto QR", fontSize = 11.sp, color = CrimsonAlert)
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Live QR Preview Card
          Card(
            colors = CardDefaults.cardColors(containerColor = CarbonCardElevated),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, EmeraldDark))),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(
              modifier = Modifier.padding(12.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(
                text = if (qrCodeImageUri.isNotBlank()) "ACTIVE CUSTOM QR CODE PREVIEW" else "DYNAMIC AUTO-GENERATED QR CODE PREVIEW",
                style = MaterialTheme.typography.labelSmall,
                color = if (qrCodeImageUri.isNotBlank()) AmberGold else EmeraldNeon,
                fontWeight = FontWeight.Bold
              )
              Spacer(modifier = Modifier.height(8.dp))
              Box(
                modifier = Modifier
                  .size(140.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color.White)
                  .padding(6.dp),
                contentAlignment = Alignment.Center
              ) {
                val previewQrUrl = if (qrCodeImageUri.isNotBlank()) {
                  qrCodeImageUri
                } else {
                  "https://api.qrserver.com/v1/create-qr-code/?size=300x300&margin=8&data=" + Uri.encode("upi://pay?pa=$adminUpiId&pn=${Uri.encode(adminPayeeName)}&cu=INR")
                }
                AsyncImage(
                  model = previewQrUrl,
                  contentDescription = "Admin QR Code Preview",
                  modifier = Modifier.fillMaxSize()
                )
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = if (qrCodeImageUri.isNotBlank()) "Custom uploaded QR code active" else "Auto-generated for UPI: $adminUpiId",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
                fontSize = 10.sp
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = minDepositStr,
              onValueChange = { minDepositStr = it },
              label = { Text("Min Deposit (₹)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )

            OutlinedTextField(
              value = minWithdrawalStr,
              onValueChange = { minWithdrawalStr = it },
              label = { Text("Min Withdrawal (₹)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = refTier1Str,
              onValueChange = { refTier1Str = it },
              label = { Text("Referral 1st Win (%)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )

            OutlinedTextField(
              value = refTier2Str,
              onValueChange = { refTier2Str = it },
              label = { Text("Subsequent Wins (%)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
              singleLine = true,
              modifier = Modifier.weight(1f)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = announcement,
            onValueChange = { announcement = it },
            label = { Text("Home Scrim Announcement Notice") },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            modifier = Modifier.fillMaxWidth()
          )

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = telegramHelpUrl,
            onValueChange = { telegramHelpUrl = it },
            label = { Text("Telegram Help Channel Link") },
            placeholder = { Text("https://t.me/your_telegram_channel") },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_telegram_help_url")
          )

          Spacer(modifier = Modifier.height(14.dp))

          Button(
            onClick = {
              val updated = currentSettings.copy(
                adminUpiId = adminUpiId.trim(),
                adminPayeeName = adminPayeeName.trim(),
                minDepositAmount = minDepositStr.toDoubleOrNull() ?: 50.0,
                minWithdrawalAmount = minWithdrawalStr.toDoubleOrNull() ?: 100.0,
                referralFirstWinPercent = refTier1Str.toDoubleOrNull() ?: 5.0,
                referralSubsequentWinPercent = refTier2Str.toDoubleOrNull() ?: 1.0,
                announcementNotice = announcement.trim(),
                telegramHelpUrl = telegramHelpUrl.trim(),
                qrCodeImageUri = qrCodeImageUri.trim()
              )
              viewModel.saveSettings(updated)
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("btn_save_admin_settings")
          ) {
            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("SAVE CONFIGURATION", fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    // 3. HOME PROMOTIONAL BANNERS MANAGER
    item {
      Spacer(modifier = Modifier.height(20.dp))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "HOME BANNERS (${allBanners.size})",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )

        Button(
          onClick = { showAddBannerDialog = true },
          colors = ButtonDefaults.buttonColors(containerColor = CarbonCardElevated, contentColor = EmeraldNeon),
          shape = RoundedCornerShape(8.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
          modifier = Modifier.testTag("btn_add_banner")
        ) {
          Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Add Banner", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
    }

    items(allBanners) { banner ->
      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonCard),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(text = banner.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = banner.subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
            Text(text = "Target: ${banner.targetScreen.uppercase()}", style = MaterialTheme.typography.labelSmall, color = NeonCyan, fontSize = 10.sp)
          }

          IconButton(onClick = { viewModel.deleteBanner(banner) }) {
            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CrimsonAlert)
          }
        }
      }
    }
  }

  // ADD BANNER MODAL
  if (showAddBannerDialog) {
    AddBannerDialog(
      onDismiss = { showAddBannerDialog = false },
      onSave = { newBanner ->
        viewModel.addBanner(newBanner)
        showAddBannerDialog = false
      }
    )
  }

  // RESTORE BACKUP DIALOG
  if (showRestoreDialog) {
    AlertDialog(
      onDismissRequest = { showRestoreDialog = false },
      containerColor = CarbonCardElevated,
      title = { Text("Restore System Records", fontWeight = FontWeight.Black, color = TextPrimary) },
      text = {
        Column {
          Text("Paste the JSON backup file contents below:", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedTextField(
            value = jsonRestoreInput,
            onValueChange = { jsonRestoreInput = it },
            placeholder = { Text("{\"version\": 1, \"users\": [...]}") },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
            modifier = Modifier
              .fillMaxWidth()
              .height(180.dp),
            maxLines = 8
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (jsonRestoreInput.isNotBlank()) {
              viewModel.restoreBackup(jsonRestoreInput)
              showRestoreDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground)
        ) {
          Text("RESTORE RECORDS", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showRestoreDialog = false }) { Text("CANCEL", color = TextSecondary) }
      }
    )
  }
}

@Composable
fun AddBannerDialog(
  onDismiss: () -> Unit,
  onSave: (PromotionalBanner) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var subtitle by remember { mutableStateOf("") }
  var targetScreen by remember { mutableStateOf("tournaments") }
  var pickedImageUri by remember { mutableStateOf("") }

  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia(),
    onResult = { uri ->
      if (uri != null) {
        pickedImageUri = uri.toString()
      }
    }
  )

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = CarbonCardElevated,
    title = { Text("Add Home Banner", fontWeight = FontWeight.Bold, color = TextPrimary) },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Banner Heading") },
          colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
          value = subtitle,
          onValueChange = { subtitle = it },
          label = { Text("Subtitle / Description") },
          colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldNeon, unfocusedBorderColor = CarbonBorder, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary),
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedButton(
          onClick = {
            photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(8.dp)
        ) {
          Icon(Icons.Default.Image, contentDescription = null, tint = EmeraldNeon)
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = if (pickedImageUri.isNotBlank()) "Image Selected ✓" else "Pick Image from Device", color = TextPrimary, fontSize = 12.sp)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isNotBlank()) {
            val banner = PromotionalBanner(
              id = UUID.randomUUID().toString(),
              title = title,
              subtitle = subtitle,
              imageResName = "banner_championship_1792896306125",
              customImageUri = pickedImageUri,
              targetScreen = targetScreen
            )
            onSave(banner)
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground)
      ) {
        Text("ADD BANNER", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("CANCEL", color = TextSecondary) }
    }
  )
}
