package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * HIGH-ENERGY ESPORTS SPLASH & LAUNCH ANIMATION
 * Provides a dynamic gaming entrance with rotating radar rings, glowing battle crest,
 * progressive server synchronization status, and instant transition to the main app.
 */
@Composable
fun SplashScreen(
  onFinish: () -> Unit,
  modifier: Modifier = Modifier
) {
  val scaleAnim = remember { Animatable(0.3f) }
  val alphaAnim = remember { Animatable(0f) }
  val textAlphaAnim = remember { Animatable(0f) }
  val progressAnim = remember { Animatable(0f) }
  var statusText by remember { mutableStateOf("INITIALIZING COMBAT PROTOCOLS...") }

  val infiniteTransition = rememberInfiniteTransition(label = "radar_loop")
  val rotationAngle by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 6000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "radar_spin"
  )
  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 0.95f,
    targetValue = 1.05f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "glow_pulse"
  )

  LaunchedEffect(Unit) {
    // Stage 1: Scale and fade in logo
    launch {
      scaleAnim.animateTo(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing)
      )
    }
    launch {
      alphaAnim.animateTo(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 500)
      )
    }

    // Stage 2: Reveal title and start progress ticker
    delay(400)
    launch {
      textAlphaAnim.animateTo(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 600)
      )
    }

    // Progress updates
    launch {
      progressAnim.animateTo(
        targetValue = 0.35f,
        animationSpec = tween(durationMillis = 600, easing = LinearEasing)
      )
      statusText = "SYNCHRONIZING CLOUD DATABASE..."
      delay(300)
      progressAnim.animateTo(
        targetValue = 0.8f,
        animationSpec = tween(durationMillis = 700, easing = LinearEasing)
      )
      statusText = "VERIFYING FREE FIRE SCRIMS ENGINE..."
      delay(300)
      progressAnim.animateTo(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 400, easing = LinearEasing)
      )
      statusText = "BATTLE ARENA READY • WELCOME!"
      delay(350)
      onFinish()
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(CarbonBackground)
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onFinish
      )
      .statusBarsPadding()
      .navigationBarsPadding()
      .testTag("splash_screen_container"),
    contentAlignment = Alignment.Center
  ) {
    // 1. Ambient Background Glowing Auras
    Box(
      modifier = Modifier
        .size(340.dp)
        .scale(pulseScale)
        .background(
          Brush.radialGradient(
            colors = listOf(
              EmeraldDark.copy(alpha = 0.35f),
              NeonCyan.copy(alpha = 0.15f),
              Color.Transparent
            )
          ),
          shape = CircleShape
        )
    )

    // 2. Rotating Cyber Radar / Tactical Ring
    Box(
      modifier = Modifier
        .size(240.dp)
        .rotate(rotationAngle)
        .border(
          width = 1.5.dp,
          brush = Brush.sweepGradient(
            listOf(
              EmeraldNeon,
              Color.Transparent,
              NeonCyan,
              Color.Transparent,
              EmeraldNeon
            )
          ),
          shape = CircleShape
        )
    )

    // Outer counter-rotating dashed aura
    Box(
      modifier = Modifier
        .size(270.dp)
        .rotate(-rotationAngle * 0.7f)
        .border(
          width = 1.dp,
          brush = Brush.sweepGradient(
            listOf(
              Color.Transparent,
              AmberGold.copy(alpha = 0.6f),
              Color.Transparent,
              NeonCyan.copy(alpha = 0.5f),
              Color.Transparent
            )
          ),
          shape = CircleShape
        )
    )

    // 3. Central Content: Logo + Brand + Title
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier.padding(horizontal = 24.dp)
    ) {
      // Main Crest / Logo Box
      Box(
        modifier = Modifier
          .scale(scaleAnim.value)
          .alpha(alphaAnim.value)
          .size(130.dp)
          .shadow(elevation = 24.dp, shape = RoundedCornerShape(32.dp), spotColor = EmeraldNeon)
          .clip(RoundedCornerShape(32.dp))
          .background(
            Brush.linearGradient(
              listOf(
                Color(0xFF0D2818),
                Color(0xFF04150D),
                Color(0xFF020905)
              )
            )
          )
          .border(
            width = 2.5.dp,
            brush = Brush.linearGradient(
              listOf(EmeraldNeon, NeonCyan, AmberGold)
            ),
            shape = RoundedCornerShape(32.dp)
          )
          .padding(8.dp),
        contentAlignment = Alignment.Center
      ) {
        Image(
          painter = painterResource(id = R.drawable.app_logo),
          contentDescription = "Todament Esports Logo",
          modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(24.dp))
        )
      }

      Spacer(modifier = Modifier.height(28.dp))

      // Title & Esports Typography
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.alpha(textAlphaAnim.value)
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          Icon(
            imageVector = Icons.Default.Bolt,
            contentDescription = null,
            tint = AmberGold,
            modifier = Modifier.size(22.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "TODAMENT",
            style = MaterialTheme.typography.headlineLarge,
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Black,
            letterSpacing = 4.sp,
            color = TextPrimary
          )
          Spacer(modifier = Modifier.width(6.dp))
          Icon(
            imageVector = Icons.Default.Bolt,
            contentDescription = null,
            tint = AmberGold,
            modifier = Modifier.size(22.dp)
          )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(EmeraldDark.copy(alpha = 0.3f))
            .border(1.dp, EmeraldNeon.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
            .padding(horizontal = 14.dp, vertical = 5.dp)
        ) {
          Text(
            text = "FREE FIRE BATTLE ARENA & CASH SCRIMS",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.ExtraBold,
            color = EmeraldNeon,
            letterSpacing = 1.5.sp,
            fontSize = 11.sp
          )
        }
      }
    }

    // 4. Bottom Loading Bar & Ticker
    Column(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth()
        .padding(horizontal = 32.dp, vertical = 36.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = statusText,
          style = MaterialTheme.typography.labelSmall,
          fontFamily = FontFamily.Monospace,
          color = TextSecondary,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "${(progressAnim.value * 100).toInt()}%",
          fontFamily = FontFamily.Monospace,
          color = EmeraldNeon,
          fontSize = 11.sp,
          fontWeight = FontWeight.Black
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      LinearProgressIndicator(
        progress = { progressAnim.value },
        modifier = Modifier
          .fillMaxWidth()
          .height(5.dp)
          .clip(RoundedCornerShape(4.dp)),
        color = EmeraldNeon,
        trackColor = CarbonCardElevated
      )

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = "Tap anywhere to skip",
        style = MaterialTheme.typography.bodySmall,
        color = TextMuted,
        fontSize = 11.sp
      )
    }
  }
}
