package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "promotional_banners")
data class PromotionalBanner(
  @PrimaryKey val id: String,
  val title: String,
  val subtitle: String,
  val imageResName: String = "", // e.g. "banner_championship_1792896306125"
  val customImageUri: String = "", // Local image URI picked from gallery
  val targetScreen: String = "tournaments", // "tournaments", "refer", "wallet"
  val orderIndex: Int = 0,
  val isActive: Boolean = true
)

@Entity(tableName = "app_settings")
data class AppSettings(
  @PrimaryKey val id: Int = 1,
  val adminUpiId: String = "todament@upi",
  val adminPayeeName: String = "TODAMENT ESPORTS",
  val qrCodeImageUri: String = "",
  val minDepositAmount: Double = 50.0,
  val minWithdrawalAmount: Double = 100.0,
  val referralFirstWinPercent: Double = 5.0,
  val referralSubsequentWinPercent: Double = 1.0,
  val supportContact: String = "+91 98765 43210",
  val announcementNotice: String = "Welcome to TODAMENT! Daily Free Fire Scrims & Cash Tournaments live now.",
  val telegramHelpUrl: String = "https://t.me/todament_support"
)
