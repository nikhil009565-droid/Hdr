package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import android.app.Activity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.TodamentRepository
import com.example.ui.theme.CarbonBackground
import com.example.ui.theme.CarbonBorder
import com.example.ui.theme.CarbonCard
import com.example.ui.theme.CarbonCardElevated
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldNeon
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.TodamentViewModel

@Composable
fun AuthScreen(
  viewModel: TodamentViewModel,
  onAuthSuccess: () -> Unit
) {
  var selectedTab by remember { mutableIntStateOf(0) } // 0: Login, 1: Register
  val isLoading by viewModel.isLoading.collectAsState()
  val currentUser by viewModel.currentUser.collectAsState()
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()

  // Login inputs - real user credentials
  var loginEmail by remember { mutableStateOf("") }
  var loginPassword by remember { mutableStateOf("") }
  var isPasswordVisible by remember { mutableStateOf(false) }

  // Register inputs
  var regFullName by remember { mutableStateOf("") }
  var regEmail by remember { mutableStateOf("") }
  var regPhone by remember { mutableStateOf("") }
  var regFfUid by remember { mutableStateOf("") }
  var regFfIgn by remember { mutableStateOf("") }
  var regPassword by remember { mutableStateOf("") }
  var isRegPasswordVisible by remember { mutableStateOf(false) }
  var regReferralCode by remember { mutableStateOf("") }

  // Automatically transition when authentication succeeds
  LaunchedEffect(currentUser) {
    if (currentUser != null) {
      onAuthSuccess()
    }
  }

  val scrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CarbonBackground)
      .verticalScroll(scrollState)
      .padding(24.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Spacer(modifier = Modifier.height(32.dp))

    // App Branding Logo & Header
    Box(
      modifier = Modifier
        .size(80.dp)
        .clip(RoundedCornerShape(20.dp))
        .background(Brush.linearGradient(listOf(EmeraldNeon, NeonCyan)))
        .padding(3.dp),
      contentAlignment = Alignment.Center
    ) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .clip(RoundedCornerShape(17.dp))
          .background(CarbonBackground),
        contentAlignment = Alignment.Center
      ) {
        Image(
          painter = painterResource(id = R.drawable.app_logo),
          contentDescription = "Todament Esports Logo",
          modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(17.dp))
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))
    Text(
      text = "TODAMENT",
      style = MaterialTheme.typography.headlineMedium,
      fontWeight = FontWeight.Black,
      letterSpacing = 2.sp,
      color = TextPrimary
    )
    Text(
      text = "FREE FIRE ESPORTS & CASH SCRIMS",
      style = MaterialTheme.typography.labelSmall,
      color = EmeraldNeon,
      letterSpacing = 1.5.sp
    )

    Spacer(modifier = Modifier.height(28.dp))

    // Login / Register Tabs
    TabRow(
      selectedTabIndex = selectedTab,
      containerColor = CarbonCard,
      contentColor = EmeraldNeon,
      indicator = { tabPositions ->
        TabRowDefaults.SecondaryIndicator(
          modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
          color = EmeraldNeon,
          height = 3.dp
        )
      },
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(12.dp))
        .border(1.dp, CarbonBorder, RoundedCornerShape(12.dp))
    ) {
      Tab(
        selected = selectedTab == 0,
        onClick = { selectedTab = 0 },
        text = {
          Text(
            text = "SIGN IN",
            fontWeight = FontWeight.Bold,
            color = if (selectedTab == 0) EmeraldNeon else TextSecondary
          )
        },
        modifier = Modifier.testTag("tab_sign_in")
      )
      Tab(
        selected = selectedTab == 1,
        onClick = { selectedTab = 1 },
        text = {
          Text(
            text = "PLAYER SIGN UP",
            fontWeight = FontWeight.Bold,
            color = if (selectedTab == 1) EmeraldNeon else TextSecondary
          )
        },
        modifier = Modifier.testTag("tab_sign_up")
      )
    }

    Spacer(modifier = Modifier.height(20.dp))

    if (selectedTab == 0) {
      // --- SIGN IN TAB ---
      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Text(
            text = "Welcome Back",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          Text(
            text = "Login to participate in scrims and withdraw cash",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
          )

          Spacer(modifier = Modifier.height(16.dp))

          OutlinedTextField(
            value = loginEmail,
            onValueChange = { loginEmail = it },
            label = { Text("Email or Phone") },
            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = EmeraldNeon) },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldNeon,
              unfocusedBorderColor = CarbonBorder,
              focusedLabelColor = EmeraldNeon,
              unfocusedLabelColor = TextMuted,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_login_email")
          )

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = loginPassword,
            onValueChange = { loginPassword = it },
            label = { Text("Password") },
            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = EmeraldNeon) },
            trailingIcon = {
              IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                Icon(
                  imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                  contentDescription = "Toggle password visibility",
                  tint = TextMuted
                )
              }
            },
            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldNeon,
              unfocusedBorderColor = CarbonBorder,
              focusedLabelColor = EmeraldNeon,
              unfocusedLabelColor = TextMuted,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_login_password")
          )

          Spacer(modifier = Modifier.height(20.dp))

          Button(
            onClick = {
              if (loginEmail.isNotBlank()) {
                viewModel.login(loginEmail, loginPassword)
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
            shape = RoundedCornerShape(10.dp),
            enabled = !isLoading,
            modifier = Modifier
              .fillMaxWidth()
              .height(50.dp)
              .testTag("btn_login_submit")
          ) {
            if (isLoading) {
              CircularProgressIndicator(modifier = Modifier.size(24.dp), color = CarbonBackground)
            } else {
              Text(text = "LOG IN TO ARENA", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedButton(
            onClick = {
              val activity = context as? Activity
              if (activity != null) {
                viewModel.googleAuthManager.signInWithGoogle(
                  activity = activity,
                  scope = coroutineScope,
                  onSuccess = { email, displayName ->
                    viewModel.loginWithGoogle(email, displayName)
                  },
                  onError = { _ -> }
                )
              }
            },
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
              .fillMaxWidth()
              .height(50.dp)
              .testTag("btn_google_signin")
          ) {
            Text(text = "Sign in with Google", fontWeight = FontWeight.Bold, color = TextPrimary)
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Link to switch to Sign Up
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Don't have an account? ",
              color = TextSecondary,
              fontSize = 13.sp
            )
            Text(
              text = "Sign Up",
              color = EmeraldNeon,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              modifier = Modifier
                .clickable { selectedTab = 1 }
                .testTag("link_switch_to_register")
            )
          }
        }
      }
    } else {
      // --- REGISTER TAB (MANDATORY GAMER PROFILE) ---
      Card(
        colors = CardDefaults.cardColors(containerColor = CarbonCard),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(CarbonBorder, CarbonBorder))),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Text(
            text = "Create Gamer Profile",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          Text(
            text = "Enter your Free Fire in-game credentials",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
          )

          Spacer(modifier = Modifier.height(14.dp))

          OutlinedTextField(
            value = regFullName,
            onValueChange = { regFullName = it },
            label = { Text("Full Name") },
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = EmeraldNeon) },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldNeon,
              unfocusedBorderColor = CarbonBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_reg_name")
          )

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = regEmail,
            onValueChange = { regEmail = it },
            label = { Text("Email Address") },
            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = EmeraldNeon) },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldNeon,
              unfocusedBorderColor = CarbonBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_reg_email")
          )

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = regPhone,
            onValueChange = { regPhone = it },
            label = { Text("Phone Number (WhatsApp)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = EmeraldNeon) },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldNeon,
              unfocusedBorderColor = CarbonBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_reg_phone")
          )

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = regFfUid,
            onValueChange = { regFfUid = it },
            label = { Text("Free Fire UID (Numeric ID)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            leadingIcon = { Icon(Icons.Default.Games, contentDescription = null, tint = EmeraldNeon) },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldNeon,
              unfocusedBorderColor = CarbonBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_reg_ff_uid")
          )

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = regFfIgn,
            onValueChange = { regFfIgn = it },
            label = { Text("Free Fire IGN (In-Game Name)") },
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = EmeraldNeon) },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldNeon,
              unfocusedBorderColor = CarbonBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_reg_ff_ign")
          )

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = regPassword,
            onValueChange = { regPassword = it },
            label = { Text("Account Password") },
            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = EmeraldNeon) },
            trailingIcon = {
              IconButton(onClick = { isRegPasswordVisible = !isRegPasswordVisible }) {
                Icon(
                  imageVector = if (isRegPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                  contentDescription = "Toggle password visibility",
                  tint = TextMuted
                )
              }
            },
            visualTransformation = if (isRegPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldNeon,
              unfocusedBorderColor = CarbonBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_reg_password")
          )

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = regReferralCode,
            onValueChange = { regReferralCode = it },
            label = { Text("Referral Code (Optional)") },
            placeholder = { Text("e.g. TODA-7721") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = EmeraldNeon,
              unfocusedBorderColor = CarbonBorder,
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("input_reg_referral")
          )

          Spacer(modifier = Modifier.height(18.dp))

          Button(
            onClick = {
              if (regEmail.isNotBlank() && regFfUid.isNotBlank() && regFfIgn.isNotBlank()) {
                viewModel.register(
                  email = regEmail,
                  fullName = regFullName.ifBlank { regFfIgn },
                  phone = regPhone,
                  ffUid = regFfUid,
                  ffIgn = regFfIgn,
                  password = regPassword,
                  referralCode = regReferralCode
                )
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = EmeraldNeon, contentColor = CarbonBackground),
            shape = RoundedCornerShape(10.dp),
            enabled = !isLoading,
            modifier = Modifier
              .fillMaxWidth()
              .height(50.dp)
              .testTag("btn_register_submit")
          ) {
            if (isLoading) {
              CircularProgressIndicator(modifier = Modifier.size(24.dp), color = CarbonBackground)
            } else {
              Text(text = "COMPLETE REGISTRATION", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            }
          }

          Spacer(modifier = Modifier.height(16.dp))

          // Link to switch to Sign In
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Already have an account? ",
              color = TextSecondary,
              fontSize = 13.sp
            )
            Text(
              text = "Sign In",
              color = EmeraldNeon,
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
              modifier = Modifier
                .clickable { selectedTab = 0 }
                .testTag("link_switch_to_login")
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))
    Text(
      text = "Strict Anti-Cheat & Fair Play Guaranteed",
      style = MaterialTheme.typography.bodySmall,
      color = TextMuted,
      fontSize = 12.sp
    )
  }
}
