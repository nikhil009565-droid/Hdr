package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Registration
import kotlinx.coroutines.flow.Flow

@Dao
interface RegistrationDao {
  @Query("SELECT * FROM registrations WHERE tournamentId = :tournamentId ORDER BY registeredAt ASC")
  fun getRegistrationsForTournament(tournamentId: String): Flow<List<Registration>>

  @Query("SELECT * FROM registrations WHERE tournamentId = :tournamentId")
  suspend fun getRegistrationsForTournamentSync(tournamentId: String): List<Registration>

  @Query("SELECT * FROM registrations WHERE userEmail = :userEmail ORDER BY registeredAt DESC")
  fun getRegistrationsForUser(userEmail: String): Flow<List<Registration>>

  @Query("SELECT * FROM registrations WHERE tournamentId = :tournamentId AND userEmail = :userEmail LIMIT 1")
  suspend fun getRegistration(tournamentId: String, userEmail: String): Registration?

  @Query("SELECT * FROM registrations")
  fun getAllRegistrations(): Flow<List<Registration>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRegistration(registration: Registration)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertRegistrations(registrations: List<Registration>)

  @Update
  suspend fun updateRegistration(registration: Registration)

  @Delete
  suspend fun deleteRegistration(registration: Registration)

  @Query("DELETE FROM registrations WHERE tournamentId = :tournamentId")
  suspend fun deleteRegistrationsForTournament(tournamentId: String)
}
