package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "registrations")
data class Registration(
  @PrimaryKey val id: String,
  val tournamentId: String,
  val userEmail: String,
  val teamName: String,
  val playerIgn: String,
  val playerUid: String,
  val teammatesJson: String = "", // Stored JSON of teammate names and UIDs for Duo/Squad
  val entryFeePaid: Double,
  val registeredAt: Long = System.currentTimeMillis(),
  val kills: Int = 0,
  val placementRank: Int = 0, // 1 for 1st, 2 for 2nd, etc.
  val prizeWon: Double = 0.0
)

data class TeammateInfo(
  val ign: String,
  val uid: String
)
