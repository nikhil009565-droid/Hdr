package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Tournament
import kotlinx.coroutines.flow.Flow

@Dao
interface TournamentDao {
  @Query("SELECT * FROM tournaments ORDER BY matchTimestamp ASC")
  fun getAllTournaments(): Flow<List<Tournament>>

  @Query("SELECT * FROM tournaments WHERE id = :id LIMIT 1")
  fun getTournamentById(id: String): Flow<Tournament?>

  @Query("SELECT * FROM tournaments WHERE id = :id LIMIT 1")
  suspend fun getTournamentByIdSync(id: String): Tournament?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTournament(tournament: Tournament)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTournaments(tournaments: List<Tournament>)

  @Update
  suspend fun updateTournament(tournament: Tournament)

  @Delete
  suspend fun deleteTournament(tournament: Tournament)

  @Query("DELETE FROM tournaments WHERE id = :id")
  suspend fun deleteTournamentById(id: String)
}
