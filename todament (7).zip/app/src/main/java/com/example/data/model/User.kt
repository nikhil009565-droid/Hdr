package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
  @PrimaryKey val email: String,
  val fullName: String,
  val phoneNumber: String,
  val freeFireUid: String,
  val freeFireIgn: String,
  val referralCode: String,
  val referredByCode: String = "",
  val password: String = "",
  val walletBalance: Double = 0.0,
  val totalDeposited: Double = 0.0,
  val totalWinnings: Double = 0.0,
  val totalWithdrawn: Double = 0.0,
  val reservedForWithdrawal: Double = 0.0,
  val isAdmin: Boolean = false,
  val createdAt: Long = System.currentTimeMillis()
)
