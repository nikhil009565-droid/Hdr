package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.AppSettings
import com.example.data.model.DepositBackupItem
import com.example.data.model.DepositRequest
import com.example.data.model.MatchFormat
import com.example.data.model.MatchStatus
import com.example.data.model.PromotionalBanner
import com.example.data.model.Registration
import com.example.data.model.RegistrationBackupItem
import com.example.data.model.RequestStatus
import com.example.data.model.TodamentBackup
import com.example.data.model.Tournament
import com.example.data.model.TournamentBackupItem
import com.example.data.model.TransactionBackupItem
import com.example.data.model.TransactionType
import com.example.data.model.User
import com.example.data.model.UserBackupItem
import com.example.data.model.WalletTransaction
import com.example.data.model.WithdrawalBackupItem
import com.example.data.model.WithdrawalRequest
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import com.example.data.firestore.FirestoreSyncManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

class TodamentRepository(
  private val database: AppDatabase,
  val firestoreSyncManager: FirestoreSyncManager? = null
) {
  private val userDao = database.userDao()
  private val tournamentDao = database.tournamentDao()
  private val registrationDao = database.registrationDao()
  private val walletDao = database.walletDao()
  private val appConfigDao = database.appConfigDao()

  val moshi: Moshi = Moshi.Builder()
    .add(KotlinJsonAdapterFactory())
    .build()

  companion object {
    const val SUPER_ADMIN_EMAIL = "firefree60510@gmail.com"
    const val SUPER_ADMIN_PASSWORD = "danger10"
  }

  // --- Initialization / Seeding ---
  suspend fun initializeDefaultData() = withContext(Dispatchers.IO) {
    // 1. Settings
    if (appConfigDao.getSettingsSync() == null) {
      appConfigDao.saveSettings(AppSettings())
    }

    // 2. Admin & Demo Users
    if (userDao.getUserSync(SUPER_ADMIN_EMAIL) == null) {
      val admin = User(
        email = SUPER_ADMIN_EMAIL,
        fullName = "TODAMENT Operator",
        phoneNumber = "+91 9988776655",
        freeFireUid = "1000000001",
        freeFireIgn = "TODAMENT_OP",
        referralCode = "TODA-ADMIN",
        password = SUPER_ADMIN_PASSWORD,
        walletBalance = 25000.0,
        totalDeposited = 25000.0,
        isAdmin = true
      )
      userDao.insertUser(admin)
    }

    // Purge any residual demo player dummy records
    userDao.deleteUserByEmail("pro_player@gmail.com")
    walletDao.deleteTransactionsByEmail("pro_player@gmail.com")

    // 2. Super Admin Account
    if (userDao.getUserSync(SUPER_ADMIN_EMAIL) == null) {
      val admin = User(
        email = SUPER_ADMIN_EMAIL,
        fullName = "TODAMENT Operator",
        phoneNumber = "+91 9988776655",
        freeFireUid = "1000000001",
        freeFireIgn = "TODAMENT_OP",
        referralCode = "TODA-ADMIN",
        password = SUPER_ADMIN_PASSWORD,
        walletBalance = 25000.0,
        totalDeposited = 25000.0,
        isAdmin = true
      )
      userDao.insertUser(admin)
    }

    // 3. Initial Banners
    val existingBanners = appConfigDao.getAllBanners()
    // Seed initial banners if empty
    val bannerList = listOf(
      PromotionalBanner(
        id = "banner_1",
        title = "FREE FIRE WORLD SERIES",
        subtitle = "Grand Finals Championship • ₹2,00,000 Prize Pool",
        imageResName = "banner_championship_1792896306125",
        targetScreen = "tournaments",
        orderIndex = 0
      ),
      PromotionalBanner(
        id = "banner_2",
        title = "DAILY CASH SCRIMS",
        subtitle = "Battle Royale Scrims Starting Hourly • Instant Payouts",
        imageResName = "banner_daily_scrims_1792896326160",
        targetScreen = "tournaments",
        orderIndex = 1
      ),
      PromotionalBanner(
        id = "banner_3",
        title = "REFER & EARN 5% COMMISSION",
        subtitle = "Invite squadmates and earn on every tournament victory",
        imageResName = "banner_refer_earn_1792896345844",
        targetScreen = "refer",
        orderIndex = 2
      )
    )
    appConfigDao.insertBanners(bannerList)

    // 4. Initial Tournaments (Clean match cards with 0 filled slots, ready for real registrations)
    val now = System.currentTimeMillis()
    val sampleTournaments = listOf(
      Tournament(
        id = "ff_match_001",
        title = "Bermuda Booyah Mega Scrim #101",
        mapName = "Bermuda",
        format = MatchFormat.SQUAD,
        entryFee = 100.0,
        totalPrizePool = 3500.0,
        firstPrize = 1800.0,
        secondPrize = 1000.0,
        thirdPrize = 400.0,
        perKillBonus = 30.0,
        matchDate = "2026-10-25",
        startTime = "21:00 IST",
        registrationClosingTime = "20:45 IST",
        matchTimestamp = now + (3 * 3600 * 1000),
        totalSlots = 12,
        filledSlots = 0,
        status = MatchStatus.OPEN,
        roomId = "998241",
        roomPassword = "ffwin"
      ),
      Tournament(
        id = "ff_match_002",
        title = "Purgatory Solo Sniper Frenzy",
        mapName = "Purgatory",
        format = MatchFormat.SOLO,
        entryFee = 30.0,
        totalPrizePool = 1200.0,
        firstPrize = 650.0,
        secondPrize = 350.0,
        thirdPrize = 100.0,
        perKillBonus = 10.0,
        matchDate = "2026-10-25",
        startTime = "22:00 IST",
        registrationClosingTime = "21:45 IST",
        matchTimestamp = now + (4 * 3600 * 1000),
        totalSlots = 48,
        filledSlots = 0,
        status = MatchStatus.OPEN
      ),
      Tournament(
        id = "ff_match_003",
        title = "Kalahari Duo Rush Champions",
        mapName = "Kalahari",
        format = MatchFormat.DUO,
        entryFee = 60.0,
        totalPrizePool = 2000.0,
        firstPrize = 1100.0,
        secondPrize = 600.0,
        thirdPrize = 200.0,
        perKillBonus = 20.0,
        matchDate = "2026-10-25",
        startTime = "23:00 IST",
        registrationClosingTime = "22:45 IST",
        matchTimestamp = now + (5 * 3600 * 1000),
        totalSlots = 24,
        filledSlots = 0,
        status = MatchStatus.OPEN
      ),
      Tournament(
        id = "ff_match_004",
        title = "NexTerra Clash Squad Pro Cup",
        mapName = "NexTerra",
        format = MatchFormat.CLASH_SQUAD,
        entryFee = 150.0,
        totalPrizePool = 5000.0,
        firstPrize = 3200.0,
        secondPrize = 1800.0,
        thirdPrize = 0.0,
        perKillBonus = 25.0,
        matchDate = "2026-10-26",
        startTime = "18:00 IST",
        registrationClosingTime = "17:45 IST",
        matchTimestamp = now + (20 * 3600 * 1000),
        totalSlots = 8,
        filledSlots = 0,
        status = MatchStatus.OPEN
      )
    )
    tournamentDao.insertTournaments(sampleTournaments)
  }

  // --- User Flow ---
  fun getUser(email: String): Flow<User?> = userDao.getUser(email)
  suspend fun getUserSync(email: String): User? = userDao.getUserSync(email)
  fun getAllUsers(): Flow<List<User>> = userDao.getAllUsers()
  fun getReferredUsers(referralCode: String): Flow<List<User>> = userDao.getReferredUsers(referralCode)

  suspend fun registerUser(
    email: String,
    fullName: String,
    phone: String,
    ffUid: String,
    ffIgn: String,
    password: String = "",
    referredByCode: String = ""
  ): Result<User> = withContext(Dispatchers.IO) {
    try {
      val cleanEmail = email.trim()
      val cleanPhone = phone.trim()
      val existingByEmail = userDao.getUserSync(cleanEmail)
      if (existingByEmail != null) {
        return@withContext Result.failure(Exception("An account with email $cleanEmail already exists."))
      }
      if (cleanPhone.isNotEmpty()) {
        val existingByPhone = userDao.getUserByPhone(cleanPhone)
        if (existingByPhone != null) {
          return@withContext Result.failure(Exception("An account with phone $cleanPhone already exists."))
        }
      }

      val isAdmin = cleanEmail.equals(SUPER_ADMIN_EMAIL, ignoreCase = true)
      val randomCode = "TODA-${(1000..9999).random()}"

      val newUser = User(
        email = cleanEmail,
        fullName = fullName.trim(),
        phoneNumber = cleanPhone,
        freeFireUid = ffUid.trim(),
        freeFireIgn = ffIgn.trim(),
        referralCode = randomCode,
        referredByCode = referredByCode.trim().uppercase(),
        password = if (isAdmin) SUPER_ADMIN_PASSWORD else password.trim(),
        walletBalance = if (isAdmin) 25000.0 else 0.0,
        isAdmin = isAdmin
      )
      userDao.insertUser(newUser)
      firestoreSyncManager?.syncUserToCloud(newUser)
      Result.success(newUser)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun loginUser(identifier: String, password: String = ""): Result<User> = withContext(Dispatchers.IO) {
    try {
      val cleanId = identifier.trim()
      val isAdmin = cleanId.equals(SUPER_ADMIN_EMAIL, ignoreCase = true)

      if (isAdmin) {
        if (password.isNotEmpty() && password != SUPER_ADMIN_PASSWORD) {
          return@withContext Result.failure(Exception("Incorrect Admin Password! Please enter '$SUPER_ADMIN_PASSWORD'."))
        }
        val admin = userDao.getUserSync(SUPER_ADMIN_EMAIL) ?: User(
          email = SUPER_ADMIN_EMAIL,
          fullName = "TODAMENT Operator",
          phoneNumber = "+91 9988776655",
          freeFireUid = "1000000001",
          freeFireIgn = "TODAMENT_OP",
          referralCode = "TODA-ADMIN",
          password = SUPER_ADMIN_PASSWORD,
          walletBalance = 25000.0,
          isAdmin = true
        ).also { 
          userDao.insertUser(it)
          firestoreSyncManager?.syncUserToCloud(it)
        }
        return@withContext Result.success(admin)
      }

      // Check user by Email first, then by Phone number
      var user = userDao.getUserSync(cleanId)
      if (user == null) {
        user = userDao.getUserByPhone(cleanId)
      }
      // If user not in local database (e.g. app re-installed), restore from Firestore cloud
      if (user == null && firestoreSyncManager != null) {
        user = firestoreSyncManager.fetchUserFromCloud(cleanId)
      }

      if (user != null) {
        if (user.password.isNotEmpty() && password.isNotEmpty() && user.password != password.trim()) {
          return@withContext Result.failure(Exception("Incorrect Password! Please check and try again."))
        }
        firestoreSyncManager?.syncUserToCloud(user)
        Result.success(user)
      } else {
        Result.failure(Exception("No account found with '$cleanId'. Please Sign Up to create your gamer account."))
      }
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun updateUserProfile(user: User) = withContext(Dispatchers.IO) {
    userDao.updateUser(user)
  }

  suspend fun adminAdjustUserBalance(
    userEmail: String,
    amountDelta: Double,
    reason: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val user = userDao.getUserSync(userEmail)
        ?: return@withContext Result.failure(Exception("User $userEmail not found"))

      val newBalance = (user.walletBalance + amountDelta).coerceAtLeast(0.0)
      val updatedUser = user.copy(walletBalance = newBalance)
      userDao.updateUser(updatedUser)
      firestoreSyncManager?.syncUserToCloud(updatedUser)

      val txType = if (amountDelta >= 0) TransactionType.DEPOSIT else TransactionType.WITHDRAWAL
      val txTitle = if (amountDelta >= 0) "Admin Funds Added" else "Admin Balance Deduction"
      val txDesc = if (reason.isNotBlank()) reason else "Direct wallet adjustment by Admin Operator"

      walletDao.insertTransaction(
        WalletTransaction(
          id = UUID.randomUUID().toString(),
          userEmail = userEmail,
          type = txType,
          amount = kotlin.math.abs(amountDelta),
          title = txTitle,
          description = txDesc,
          referenceId = "ADMIN_MOD_${System.currentTimeMillis()}"
        )
      )
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  // --- Tournaments Flow ---
  fun getAllTournaments(): Flow<List<Tournament>> = tournamentDao.getAllTournaments()
  fun getTournament(id: String): Flow<Tournament?> = tournamentDao.getTournamentById(id)

  suspend fun registerForTournament(
    tournamentId: String,
    userEmail: String,
    teamName: String,
    teammates: List<Pair<String, String>> // List of (IGN, UID)
  ): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val tournament = tournamentDao.getTournamentByIdSync(tournamentId)
        ?: return@withContext Result.failure(Exception("Tournament not found"))

      if (tournament.status != MatchStatus.OPEN) {
        return@withContext Result.failure(Exception("Registration is ${tournament.status.displayName}"))
      }

      if (tournament.filledSlots >= tournament.totalSlots) {
        return@withContext Result.failure(Exception("Tournament slots are completely full!"))
      }

      val existingReg = registrationDao.getRegistration(tournamentId, userEmail)
      if (existingReg != null) {
        return@withContext Result.failure(Exception("You have already joined this tournament!"))
      }

      val user = userDao.getUserSync(userEmail)
        ?: return@withContext Result.failure(Exception("User not found"))

      if (user.walletBalance < tournament.entryFee) {
        return@withContext Result.failure(Exception("Insufficient wallet balance! Please add funds to register."))
      }

      // Convert teammates to JSON
      val teammatesJson = if (teammates.isNotEmpty()) {
        moshi.adapter(Array<Array<String>>::class.java).toJson(
          teammates.map { arrayOf(it.first, it.second) }.toTypedArray()
        )
      } else ""

      // 1. Deduct wallet balance
      val updatedUser = user.copy(walletBalance = user.walletBalance - tournament.entryFee)
      userDao.updateUser(updatedUser)

      // 2. Insert transaction
      walletDao.insertTransaction(
        WalletTransaction(
          id = UUID.randomUUID().toString(),
          userEmail = userEmail,
          type = TransactionType.ENTRY_FEE,
          amount = tournament.entryFee,
          title = "Joined ${tournament.title}",
          description = "Entry fee paid for ${tournament.format.displayName} slot",
          referenceId = tournament.id
        )
      )

      // 3. Create registration
      val registration = Registration(
        id = UUID.randomUUID().toString(),
        tournamentId = tournamentId,
        userEmail = userEmail,
        teamName = teamName.ifBlank { user.freeFireIgn },
        playerIgn = user.freeFireIgn,
        playerUid = user.freeFireUid,
        teammatesJson = teammatesJson,
        entryFeePaid = tournament.entryFee
      )
      registrationDao.insertRegistration(registration)

      // 4. Update tournament filled slots
      val newFilled = tournament.filledSlots + 1
      val newStatus = if (newFilled >= tournament.totalSlots) MatchStatus.FULL else MatchStatus.OPEN
      tournamentDao.updateTournament(tournament.copy(filledSlots = newFilled, status = newStatus))

      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  fun getRegistrationsForTournament(tournamentId: String): Flow<List<Registration>> =
    registrationDao.getRegistrationsForTournament(tournamentId)

  fun getRegistrationsForUser(userEmail: String): Flow<List<Registration>> =
    registrationDao.getRegistrationsForUser(userEmail)

  // --- Wallet & 1-Tap UPI Deposit Flow ---
  fun getTransactions(userEmail: String): Flow<List<WalletTransaction>> =
    walletDao.getTransactionsForUser(userEmail)

  fun getAllTransactions(): Flow<List<WalletTransaction>> =
    walletDao.getAllTransactions()

  fun getDepositRequests(userEmail: String): Flow<List<DepositRequest>> =
    walletDao.getDepositRequestsForUser(userEmail)

  fun getAllDepositRequests(): Flow<List<DepositRequest>> =
    walletDao.getAllDepositRequests()

  suspend fun submitDepositRequest(
    userEmail: String,
    amount: Double,
    utrNumber: String,
    screenshotUri: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val user = userDao.getUserSync(userEmail)
        ?: return@withContext Result.failure(Exception("User not found"))

      val cleanUtr = utrNumber.trim()
      if (cleanUtr.length != 12 || !cleanUtr.all { it.isDigit() }) {
        return@withContext Result.failure(Exception("Please enter a valid 12-digit numeric UTR reference number."))
      }

      val request = DepositRequest(
        id = UUID.randomUUID().toString(),
        userEmail = userEmail,
        userName = user.fullName,
        userPhone = user.phoneNumber,
        amount = amount,
        utrNumber = cleanUtr,
        screenshotUri = screenshotUri,
        status = RequestStatus.PENDING
      )
      walletDao.insertDepositRequest(request)
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun approveDepositRequest(requestId: String) = withContext(Dispatchers.IO) {
    val request = walletDao.getDepositRequestById(requestId) ?: return@withContext
    if (request.status != RequestStatus.PENDING) return@withContext

    val user = userDao.getUserSync(request.userEmail) ?: return@withContext
    val updatedUser = user.copy(
      walletBalance = user.walletBalance + request.amount,
      totalDeposited = user.totalDeposited + request.amount
    )
    userDao.updateUser(updatedUser)

    walletDao.insertTransaction(
      WalletTransaction(
        id = UUID.randomUUID().toString(),
        userEmail = request.userEmail,
        type = TransactionType.DEPOSIT,
        amount = request.amount,
        title = "UPI Deposit Verified",
        description = "UTR: ${request.utrNumber}",
        referenceId = request.utrNumber
      )
    )

    walletDao.updateDepositRequest(
      request.copy(
        status = RequestStatus.APPROVED,
        resolvedAt = System.currentTimeMillis()
      )
    )
  }

  suspend fun rejectDepositRequest(requestId: String, reason: String) = withContext(Dispatchers.IO) {
    val request = walletDao.getDepositRequestById(requestId) ?: return@withContext
    walletDao.updateDepositRequest(
      request.copy(
        status = RequestStatus.REJECTED,
        adminComment = reason,
        resolvedAt = System.currentTimeMillis()
      )
    )
  }

  // --- Instant UPI Withdrawal Flow ---
  fun getWithdrawalRequests(userEmail: String): Flow<List<WithdrawalRequest>> =
    walletDao.getWithdrawalRequestsForUser(userEmail)

  fun getAllWithdrawalRequests(): Flow<List<WithdrawalRequest>> =
    walletDao.getAllWithdrawalRequests()

  suspend fun submitWithdrawalRequest(
    userEmail: String,
    amount: Double,
    upiId: String,
    accountHolderName: String
  ): Result<Unit> = withContext(Dispatchers.IO) {
    try {
      val user = userDao.getUserSync(userEmail)
        ?: return@withContext Result.failure(Exception("User not found"))

      val settings = appConfigDao.getSettingsSync() ?: AppSettings()
      if (amount < settings.minWithdrawalAmount) {
        return@withContext Result.failure(Exception("Minimum withdrawal amount is ₹${settings.minWithdrawalAmount}"))
      }

      if (user.walletBalance < amount) {
        return@withContext Result.failure(Exception("Insufficient balance for withdrawal!"))
      }

      if (!upiId.contains("@") || upiId.length < 5) {
        return@withContext Result.failure(Exception("Please enter a valid UPI ID (e.g. name@oksbi)"))
      }

      // Atomic reservation: deduct from walletBalance into reservedForWithdrawal immediately
      val updatedUser = user.copy(
        walletBalance = user.walletBalance - amount,
        reservedForWithdrawal = user.reservedForWithdrawal + amount
      )
      userDao.updateUser(updatedUser)

      val request = WithdrawalRequest(
        id = UUID.randomUUID().toString(),
        userEmail = userEmail,
        userName = user.fullName,
        amount = amount,
        upiId = upiId.trim(),
        accountHolderName = accountHolderName.trim(),
        status = RequestStatus.PENDING
      )
      walletDao.insertWithdrawalRequest(request)

      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun markWithdrawalPaid(requestId: String, payoutRef: String) = withContext(Dispatchers.IO) {
    val request = walletDao.getWithdrawalRequestById(requestId) ?: return@withContext
    if (request.status != RequestStatus.PENDING) return@withContext

    val user = userDao.getUserSync(request.userEmail) ?: return@withContext
    val updatedUser = user.copy(
      reservedForWithdrawal = (user.reservedForWithdrawal - request.amount).coerceAtLeast(0.0),
      totalWithdrawn = user.totalWithdrawn + request.amount
    )
    userDao.updateUser(updatedUser)

    walletDao.insertTransaction(
      WalletTransaction(
        id = UUID.randomUUID().toString(),
        userEmail = request.userEmail,
        type = TransactionType.WITHDRAWAL,
        amount = request.amount,
        title = "Withdrawal Dispatched to UPI",
        description = "Sent to ${request.upiId}. Payout Ref: $payoutRef",
        referenceId = payoutRef
      )
    )

    walletDao.updateWithdrawalRequest(
      request.copy(
        status = RequestStatus.APPROVED,
        payoutReference = payoutRef,
        resolvedAt = System.currentTimeMillis()
      )
    )
  }

  suspend fun rejectWithdrawalRequest(requestId: String, reason: String) = withContext(Dispatchers.IO) {
    val request = walletDao.getWithdrawalRequestById(requestId) ?: return@withContext
    if (request.status != RequestStatus.PENDING) return@withContext

    val user = userDao.getUserSync(request.userEmail) ?: return@withContext
    // Refund reserved money back to active wallet balance!
    val updatedUser = user.copy(
      walletBalance = user.walletBalance + request.amount,
      reservedForWithdrawal = (user.reservedForWithdrawal - request.amount).coerceAtLeast(0.0)
    )
    userDao.updateUser(updatedUser)

    walletDao.insertTransaction(
      WalletTransaction(
        id = UUID.randomUUID().toString(),
        userEmail = request.userEmail,
        type = TransactionType.REFUND,
        amount = request.amount,
        title = "Withdrawal Rejected & Refunded",
        description = "Reason: $reason",
        referenceId = request.id
      )
    )

    walletDao.updateWithdrawalRequest(
      request.copy(
        status = RequestStatus.REJECTED,
        rejectReason = reason,
        resolvedAt = System.currentTimeMillis()
      )
    )
  }

  // --- Admin Match Management & Results ---
  suspend fun createTournament(tournament: Tournament) = withContext(Dispatchers.IO) {
    tournamentDao.insertTournament(tournament)
    firestoreSyncManager?.syncTournamentToCloud(tournament)
  }

  suspend fun updateTournament(tournament: Tournament) = withContext(Dispatchers.IO) {
    tournamentDao.updateTournament(tournament)
    firestoreSyncManager?.syncTournamentToCloud(tournament)
  }

  suspend fun cancelTournamentAndRefund(tournamentId: String) = withContext(Dispatchers.IO) {
    val tournament = tournamentDao.getTournamentByIdSync(tournamentId) ?: return@withContext
    val registrations = registrationDao.getRegistrationsForTournamentSync(tournamentId)

    // Refund all registered players
    for (reg in registrations) {
      val user = userDao.getUserSync(reg.userEmail)
      if (user != null) {
        val refundedUser = user.copy(walletBalance = user.walletBalance + reg.entryFeePaid)
        userDao.updateUser(refundedUser)

        walletDao.insertTransaction(
          WalletTransaction(
            id = UUID.randomUUID().toString(),
            userEmail = reg.userEmail,
            type = TransactionType.REFUND,
            amount = reg.entryFeePaid,
            title = "Match Cancelled Refund",
            description = "Tournament '${tournament.title}' was cancelled by organizer",
            referenceId = tournament.id
          )
        )
      }
    }

    tournamentDao.updateTournament(tournament.copy(status = MatchStatus.CANCELLED))
  }

  suspend fun updateRoomCredentials(tournamentId: String, roomId: String, roomPassword: String, isVisible: Boolean) = withContext(Dispatchers.IO) {
    val tournament = tournamentDao.getTournamentByIdSync(tournamentId) ?: return@withContext
    tournamentDao.updateTournament(
      tournament.copy(
        roomId = roomId,
        roomPassword = roomPassword,
        isRoomVisible = isVisible
      )
    )
  }

  suspend fun distributeTournamentPrizes(
    tournamentId: String,
    results: List<Registration> // Updated with rank, kills, prizeWon
  ) = withContext(Dispatchers.IO) {
    val tournament = tournamentDao.getTournamentByIdSync(tournamentId) ?: return@withContext
    val settings = appConfigDao.getSettingsSync() ?: AppSettings()

    for (res in results) {
      registrationDao.updateRegistration(res)

      if (res.prizeWon > 0.0) {
        val winner = userDao.getUserSync(res.userEmail)
        if (winner != null) {
          val isFirstWin = winner.totalWinnings <= 0.0

          // Update winner wallet
          val updatedWinner = winner.copy(
            walletBalance = winner.walletBalance + res.prizeWon,
            totalWinnings = winner.totalWinnings + res.prizeWon
          )
          userDao.updateUser(updatedWinner)

          walletDao.insertTransaction(
            WalletTransaction(
              id = UUID.randomUUID().toString(),
              userEmail = winner.email,
              type = TransactionType.WINNING,
              amount = res.prizeWon,
              title = "Prize: Rank #${res.placementRank} in ${tournament.title}",
              description = "${res.kills} Kills + Placement Reward",
              referenceId = tournament.id
            )
          )

          // Refer & Earn Multi-Tier Rewards Trigger:
          // 5% bonus on invited friend's FIRST tournament win, 1% on subsequent wins
          if (winner.referredByCode.isNotBlank()) {
            val referrer = userDao.getUserByReferralCode(winner.referredByCode)
            if (referrer != null) {
              val bonusPercent = if (isFirstWin) settings.referralFirstWinPercent else settings.referralSubsequentWinPercent
              val bonusAmount = (res.prizeWon * (bonusPercent / 100.0)).coerceAtLeast(1.0)

              val updatedReferrer = referrer.copy(
                walletBalance = referrer.walletBalance + bonusAmount
              )
              userDao.updateUser(updatedReferrer)

              walletDao.insertTransaction(
                WalletTransaction(
                  id = UUID.randomUUID().toString(),
                  userEmail = referrer.email,
                  type = TransactionType.REFERRAL_BONUS,
                  amount = bonusAmount,
                  title = "Referral Commission (${bonusPercent}%)",
                  description = "Friend '${winner.fullName}' won ₹${res.prizeWon} in ${tournament.title}",
                  referenceId = tournament.id
                )
              )
            }
          }
        }
      }
    }

    tournamentDao.updateTournament(tournament.copy(status = MatchStatus.COMPLETED))
  }

  // --- Banners & App Settings ---
  fun getActiveBanners(): Flow<List<PromotionalBanner>> = appConfigDao.getActiveBanners()
  fun getAllBanners(): Flow<List<PromotionalBanner>> = appConfigDao.getAllBanners()

  suspend fun insertBanner(banner: PromotionalBanner) = withContext(Dispatchers.IO) {
    appConfigDao.insertBanner(banner)
  }

  suspend fun deleteBanner(banner: PromotionalBanner) = withContext(Dispatchers.IO) {
    appConfigDao.deleteBanner(banner)
  }

  fun getAppSettings(): Flow<AppSettings?> = appConfigDao.getSettings()

  suspend fun updateAppSettings(settings: AppSettings) = withContext(Dispatchers.IO) {
    appConfigDao.saveSettings(settings)
    firestoreSyncManager?.syncAppSettingsToCloud(settings)
  }

  // --- Permanent Backup & Restore ---
  suspend fun exportBackupJson(): String = withContext(Dispatchers.IO) {
    // Collect snapshot of all tables
    val userList = mutableListOf<UserBackupItem>()
    // For sync export, we can read directly
    val db = database.openHelper.readableDatabase
    val usersCursor = db.query("SELECT * FROM users")
    while (usersCursor.moveToNext()) {
      userList.add(
        UserBackupItem(
          email = usersCursor.getString(usersCursor.getColumnIndexOrThrow("email")),
          fullName = usersCursor.getString(usersCursor.getColumnIndexOrThrow("fullName")),
          phoneNumber = usersCursor.getString(usersCursor.getColumnIndexOrThrow("phoneNumber")),
          freeFireUid = usersCursor.getString(usersCursor.getColumnIndexOrThrow("freeFireUid")),
          freeFireIgn = usersCursor.getString(usersCursor.getColumnIndexOrThrow("freeFireIgn")),
          referralCode = usersCursor.getString(usersCursor.getColumnIndexOrThrow("referralCode")),
          referredByCode = usersCursor.getString(usersCursor.getColumnIndexOrThrow("referredByCode")),
          password = if (usersCursor.getColumnIndex("password") != -1) usersCursor.getString(usersCursor.getColumnIndexOrThrow("password")) else "",
          walletBalance = usersCursor.getDouble(usersCursor.getColumnIndexOrThrow("walletBalance")),
          totalDeposited = usersCursor.getDouble(usersCursor.getColumnIndexOrThrow("totalDeposited")),
          totalWinnings = usersCursor.getDouble(usersCursor.getColumnIndexOrThrow("totalWinnings")),
          totalWithdrawn = usersCursor.getDouble(usersCursor.getColumnIndexOrThrow("totalWithdrawn")),
          reservedForWithdrawal = usersCursor.getDouble(usersCursor.getColumnIndexOrThrow("reservedForWithdrawal")),
          isAdmin = usersCursor.getInt(usersCursor.getColumnIndexOrThrow("isAdmin")) == 1,
          createdAt = usersCursor.getLong(usersCursor.getColumnIndexOrThrow("createdAt"))
        )
      )
    }
    usersCursor.close()

    val tournamentList = mutableListOf<TournamentBackupItem>()
    val tournCursor = db.query("SELECT * FROM tournaments")
    while (tournCursor.moveToNext()) {
      tournamentList.add(
        TournamentBackupItem(
          id = tournCursor.getString(tournCursor.getColumnIndexOrThrow("id")),
          title = tournCursor.getString(tournCursor.getColumnIndexOrThrow("title")),
          mapName = tournCursor.getString(tournCursor.getColumnIndexOrThrow("mapName")),
          format = tournCursor.getString(tournCursor.getColumnIndexOrThrow("format")),
          entryFee = tournCursor.getDouble(tournCursor.getColumnIndexOrThrow("entryFee")),
          totalPrizePool = tournCursor.getDouble(tournCursor.getColumnIndexOrThrow("totalPrizePool")),
          firstPrize = tournCursor.getDouble(tournCursor.getColumnIndexOrThrow("firstPrize")),
          secondPrize = tournCursor.getDouble(tournCursor.getColumnIndexOrThrow("secondPrize")),
          thirdPrize = tournCursor.getDouble(tournCursor.getColumnIndexOrThrow("thirdPrize")),
          perKillBonus = tournCursor.getDouble(tournCursor.getColumnIndexOrThrow("perKillBonus")),
          matchDate = tournCursor.getString(tournCursor.getColumnIndexOrThrow("matchDate")),
          startTime = tournCursor.getString(tournCursor.getColumnIndexOrThrow("startTime")),
          registrationClosingTime = tournCursor.getString(tournCursor.getColumnIndexOrThrow("registrationClosingTime")),
          matchTimestamp = tournCursor.getLong(tournCursor.getColumnIndexOrThrow("matchTimestamp")),
          totalSlots = tournCursor.getInt(tournCursor.getColumnIndexOrThrow("totalSlots")),
          filledSlots = tournCursor.getInt(tournCursor.getColumnIndexOrThrow("filledSlots")),
          status = tournCursor.getString(tournCursor.getColumnIndexOrThrow("status")),
          customRules = tournCursor.getString(tournCursor.getColumnIndexOrThrow("customRules")),
          roomId = tournCursor.getString(tournCursor.getColumnIndexOrThrow("roomId")),
          roomPassword = tournCursor.getString(tournCursor.getColumnIndexOrThrow("roomPassword")),
          isRoomVisible = tournCursor.getInt(tournCursor.getColumnIndexOrThrow("isRoomVisible")) == 1
        )
      )
    }
    tournCursor.close()

    val backup = TodamentBackup(
      version = 1,
      exportTimestamp = System.currentTimeMillis(),
      users = userList,
      tournaments = tournamentList
    )

    moshi.adapter(TodamentBackup::class.java).indent("  ").toJson(backup)
  }

  suspend fun restoreBackupJson(jsonString: String): Result<Int> = withContext(Dispatchers.IO) {
    try {
      val backup = moshi.adapter(TodamentBackup::class.java).fromJson(jsonString)
        ?: return@withContext Result.failure(Exception("Failed to parse JSON backup"))

      var restoredCount = 0
      for (u in backup.users) {
        userDao.insertUser(
          User(
            email = u.email,
            fullName = u.fullName,
            phoneNumber = u.phoneNumber,
            freeFireUid = u.freeFireUid,
            freeFireIgn = u.freeFireIgn,
            referralCode = u.referralCode,
            referredByCode = u.referredByCode,
            password = u.password,
            walletBalance = u.walletBalance,
            totalDeposited = u.totalDeposited,
            totalWinnings = u.totalWinnings,
            totalWithdrawn = u.totalWithdrawn,
            reservedForWithdrawal = u.reservedForWithdrawal,
            isAdmin = u.isAdmin,
            createdAt = u.createdAt
          )
        )
        restoredCount++
      }

      for (t in backup.tournaments) {
        tournamentDao.insertTournament(
          Tournament(
            id = t.id,
            title = t.title,
            mapName = t.mapName,
            format = try { MatchFormat.valueOf(t.format) } catch (_: Exception) { MatchFormat.SOLO },
            entryFee = t.entryFee,
            totalPrizePool = t.totalPrizePool,
            firstPrize = t.firstPrize,
            secondPrize = t.secondPrize,
            thirdPrize = t.thirdPrize,
            perKillBonus = t.perKillBonus,
            matchDate = t.matchDate,
            startTime = t.startTime,
            registrationClosingTime = t.registrationClosingTime,
            matchTimestamp = t.matchTimestamp,
            totalSlots = t.totalSlots,
            filledSlots = t.filledSlots,
            status = try { MatchStatus.valueOf(t.status) } catch (_: Exception) { MatchStatus.OPEN },
            customRules = t.customRules,
            roomId = t.roomId,
            roomPassword = t.roomPassword,
            isRoomVisible = t.isRoomVisible
          )
        )
        restoredCount++
      }

      Result.success(restoredCount)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }
}
